export const imgOTP = require( './OTP.png' );
export const imgForgotPassword = require( './ForgotPassword.png' );
export const imgLiveStream = require( './LiveStream.png' )
export const imgStoryAndChat = require( './StoryAndChat.png' )
export const imgAccountPrivate = require( './AccountPrivate.png' )
export const defaultUser = require( './defaultUser.png' )
