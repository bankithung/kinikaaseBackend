/** @format */

export const LOGO_NEW = require("./bujulo_logo.jpg");
