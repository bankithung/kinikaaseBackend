export const icnDirection = require( "./Direction.png" );
export const icnHome = require( "./Home.png" );
export const icnSearch = require( "./Search_.png" );
export const icnUpload = require( "./Upload.png" );
export const icnNotification = require( "./Notification.png" );

export const icnSelectedDirection = require( "./SelectedDirection.png" );
export const icnSelectedNotification = require( "./SelectedNotification.png" );
export const icnSelectedUpload = require( "./SelectedUpload.png" );
export const icnSelectedSearch = require( "./SelectedSearch_.png" );
export const icnSelectedHome = require( "./SelectedHome.png" );

export const icnExplore = require( './music_disable.png' )
export const icnExploreSelected = require( './music_enable.png' )


export const addUser = require( '../../adduser.png' )
export const user = require( '../../user.png' )
