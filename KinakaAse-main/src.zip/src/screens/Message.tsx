import React, { useCallback, useEffect, useLayoutEffect, useRef, useState, memo } from 'react';
import {
  Alert,
  Easing,
  PermissionsAndroid,
  Platform,
  SafeAreaView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image,
  StyleSheet,
  Animated,
  ActivityIndicator,
  Linking,
  Pressable,
  Keyboard,
} from 'react-native';
import { FlashList } from '@shopify/flash-list';
import Toast from 'react-native-simple-toast';
import { Menu, Divider } from 'react-native-paper';
import Geolocation from '@react-native-community/geolocation';
import { WebView } from 'react-native-webview';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { PanGestureHandler, State } from 'react-native-gesture-handler';
import Video from 'react-native-video';
import useGlobal from '../core/global';
import { launchImageLibrary, launchCamera } from 'react-native-image-picker';
import utils from '../core/utils';
import Clipboard from '@react-native-clipboard/clipboard';
import AudioRecorderPlayer from 'react-native-audio-recorder-player';
import secure from '../core/secure';
import Map from './map';
import ImageResizer from 'react-native-image-resizer';
import { ADDRESS } from '../core/api';
import Thumbnail from '../common/Thumbnail';
import EmojiPicker from 'rn-emoji-keyboard';
import NetInfo from '@react-native-community/netinfo';
import axios from 'axios';
import AudioPlayerT from './AudioPlayer';

// Environment configuration
const API_BASE_URL = ADDRESS;

// Asset imports
const ASSETS = {
  sendIcon: require('../assets/icons/sendM.png'),
  image: require('../assets/image.png'),
  camera: require('../assets/icons/camera.png'),
  gallery: require('../assets/icons/gallery.png'),
  location: require('../assets/icons/more/location.png'),
  videocall: require('../assets/icons/more/videocall.png'),
  voicecall: require('../assets/phone.png'),
  play: require('../assets/play.png'),
  pause: require('../assets/pause.png'),
  down: require('../assets/down.png'),
  del: require('../assets/del.png'),
  reply: require('../assets/replyM.png'),
  copy: require('../assets/copy.png'),
  close: require('../assets/close.png'),
  sendMessageIcon: require('../assets/send.png'),
  seen: require('../assets/seenM.png'),
  unseen: require('../assets/unseenM.png'),
  plus: require('../assets/plus.png'),
  pin: require('../assets/plus.png'),
  mute: require('../assets/mute.png'),
  block: require('../assets/mute.png'),
  report: require('../assets/mute.png'),
};

// Audio Recorder Instance
const audioRecorderPlayer = new AudioRecorderPlayer();
audioRecorderPlayer.setSubscriptionDuration(0.1);

// Type definitions
interface Message {
  id: string;
  text: string;
  type: string;
  created: string;
  is_me: boolean;
  seen: boolean;
  is_deleted: boolean;
  replied_to?: string | null;
  replied_to_message?: Message;
  reactions?: { emoji: string; user: string }[];
  mentions?: string[];
  pinned: boolean;
  disappearing?: number;
  incognito: boolean;
}

interface Friend {
  name: string;
  username: string;
  thumbnail?: string;
  online: boolean;
}

interface User {
  username: string;
  thumbnail?: string;
}

// MessageHeader Component
const MessageHeader = memo(({ friend, navigation, connectionId, user, isGroup, groupAdmins, onMuteToggle, onBlockUser, onReportUser }) => {
  const messageSend = useGlobal(state => state.messageSend);
  const [visible, setVisible] = useState(false);
  const scaleAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(scaleAnim, { toValue: visible ? 1 : 0, duration: 200, easing: Easing.ease, useNativeDriver: true }).start();
  }, [visible]);

  if (!friend) return null;

  const handleProfile = useCallback(() => navigation.navigate('OtherProfile', { friend }), [navigation, friend]);

  const generateID = useCallback(() => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    return Array.from({ length: 6 }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join('');
  }, []);

  const openVideoCall = useCallback(() => {
    const id = generateID();
    messageSend(connectionId, id, 'videocall', null, isGroup);
    navigation.navigate('VideoCall', { roomId: id, friend, navigation, isGroup });
  }, [connectionId, friend, navigation, messageSend, isGroup]);

  const openVoiceCall = useCallback(() => {
    const id = generateID();
    messageSend(connectionId, id, 'voicecall', null, isGroup);
    navigation.navigate('VoiceCall', { roomId: id, friend, navigation, isGroup });
  }, [connectionId, friend, navigation, messageSend, isGroup]);

  const openPlayer = useCallback(({ roomType }) => {
    const id = generateID();
    const val = roomType === 'PlayMusic' ? 'listen' : 'watch';
    messageSend(connectionId, id, val, null, isGroup);
    navigation.navigate(roomType, { roomId: id, navigation, host: user.username, isGroup });
  }, [connectionId, navigation, user.username, messageSend, isGroup]);

  return (
    <View style={styles.headerContainer}>
      <TouchableOpacity style={styles.headerLeft} onPress={handleProfile}>
        <Thumbnail url={friend.thumbnail} size={40} />
        <View style={styles.headerTextContainer}>
          <Text style={styles.headerName}>{friend.username}</Text>
          <Text style={styles.onlineStatus}>{friend.online ? 'Online' : 'Offline'}</Text>
        </View>
      </TouchableOpacity>
      <View style={styles.headerRight}>
        <TouchableOpacity onPress={openVideoCall}>
          <FontAwesomeIcon icon="video" size={20} color="black" style={styles.headerIcon} />
        </TouchableOpacity>
        <TouchableOpacity onPress={openVoiceCall}>
          <FontAwesomeIcon icon="phone" size={20} color="black" style={styles.headerIcon} />
        </TouchableOpacity>
        <Menu
          visible={visible}
          onDismiss={() => setVisible(false)}
          anchor={<TouchableOpacity onPress={() => setVisible(true)}><FontAwesomeIcon icon="ellipsis-v" size={20} color="black" /></TouchableOpacity>}
          contentStyle={[styles.menuContent, { transform: [{ scale: scaleAnim }] }]}
        >
          <Menu.Item onPress={() => { setVisible(false); openPlayer({ roomType: 'PlayMusic' }); }} title="Listen Together" titleStyle={styles.menuItemText} />
          <Divider style={styles.menuDivider} />
          <Menu.Item onPress={() => { setVisible(false); openPlayer({ roomType: 'PlayVideo' }); }} title="Watch Together" titleStyle={styles.menuItemText} />
          <Divider style={styles.menuDivider} />
          <Menu.Item onPress={() => { setVisible(false); onMuteToggle(); }} title="Mute Notifications" titleStyle={styles.menuItemText} />
          {!isGroup && (
            <>
              <Divider style={styles.menuDivider} />
              <Menu.Item onPress={() => { setVisible(false); onBlockUser(); }} title="Block User" titleStyle={styles.menuItemText} />
              <Divider style={styles.menuDivider} />
              <Menu.Item onPress={() => { setVisible(false); onReportUser(); }} title="Report User" titleStyle={styles.menuItemText} />
            </>
          )}
          {isGroup && groupAdmins.includes(user.username) && (
            <>
              <Divider style={styles.menuDivider} />
              <Menu.Item onPress={() => navigation.navigate('GroupSettings', { connectionId })} title="Group Settings" titleStyle={styles.menuItemText} />
            </>
          )}
        </Menu>
      </View>
    </View>
  );
});

// MessageBubbleMe Component
const MessageBubbleMe = memo(({ text, navigation, previousMessage, replyingTo, setReplyingTo, friend, displayedDays, onReplyPress, highlightedMessageId, onPinMessage, onEditMessage }) => {
  const user = useGlobal(state => state.user);
  const [showOptions, setShowOptions] = useState(false);
  const [token, setToken] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editText, setEditText] = useState(text.text);
  const translateX = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const fetchToken = async () => {
      const tokens = await secure.get('tokens');
      setToken(tokens?.access || '');
    };
    fetchToken();
  }, []);

  const currentMessageDay = utils.formatTimeDays(text.created);
  const previousMessageDay = previousMessage ? utils.formatTimeDays(previousMessage.created) : null;
  const shouldShowDay = !displayedDays.has(currentMessageDay) && currentMessageDay !== previousMessageDay;
  if (shouldShowDay) displayedDays.add(currentMessageDay);

  const copyToClipboard = useCallback(async () => {
    await Clipboard.setString(text.text);
    Toast.show('Copied to clipboard', Toast.SHORT);
  }, [text.text]);

  const deleteMessage = useCallback(async () => {
    try {
      await axios.post(`https://${API_BASE_URL}/chat/messages/delete/${text.id}/`, {}, { headers: { Authorization: `Bearer ${token}` } });
      Toast.show('Message deleted', Toast.SHORT);
    } catch (error) {
      Toast.show('Failed to delete', Toast.SHORT);
    }
  }, [text.id, token]);

  const handleEdit = useCallback(async () => {
    const messageTime = new Date(text.created).getTime();
    const now = new Date().getTime();
    if ((now - messageTime) > 5 * 60 * 1000) {
      Toast.show('Edit window (5 minutes) has expired', Toast.SHORT);
      setEditMode(false);
      return;
    }
    try {
      await axios.patch(`https://${API_BASE_URL}/chat/messages/edit/${text.id}/`, { text: editText }, { headers: { Authorization: `Bearer ${token}` } });
      onEditMessage(text.id, editText);
      setEditMode(false);
      Toast.show('Message edited', Toast.SHORT);
    } catch (error) {
      Toast.show('Failed to edit', Toast.SHORT);
    }
  }, [text.id, editText, token, onEditMessage]);

  const handleReaction = useCallback(async (emojiObj) => {
    const emoji = typeof emojiObj === 'object' ? emojiObj.emoji : emojiObj;
    if (!emoji || emoji.length > 255) {
      Toast.show('Invalid emoji', Toast.SHORT);
      return;
    }
    try {
      await axios.post(`https://${API_BASE_URL}/chat/messages/react/${text.id}/`, { emoji }, { headers: { Authorization: `Bearer ${token}` } });
      Toast.show('Reaction added', Toast.SHORT);
    } catch (error) {
      Toast.show('Failed to react', Toast.SHORT);
    }
  }, [text.id, token]);

  const onGestureEvent = Animated.event([{ nativeEvent: { translationX: translateX } }], { useNativeDriver: true });
  const onHandlerStateChange = (event) => {
    if (event.nativeEvent.state === State.END) {
      if (event.nativeEvent.translationX < -50) {
        setReplyingTo(text);
        Animated.timing(translateX, { toValue: -100, duration: 200, useNativeDriver: true }).start(() =>
          Animated.timing(translateX, { toValue: 0, duration: 200, useNativeDriver: true }).start()
        );
      } else {
        Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
      }
    }
  };

  const [lt, lo] = text.type === 'location' ? text.text.split(' ') : ['', ''];
  const map = Map({ lt, lo });

  const openGoogleMaps = useCallback(() => Linking.openURL(Platform.select({ ios: `https://maps.apple.com/?ll=${lt},${lo}`, android: `google.navigation:q=${lt},${lo}` })), [lt, lo]);
  const openCameras = useCallback(() => navigation.navigate('VideoCall', { roomId: text.text, navigation, friend }), [navigation, text.text, friend]);
  const openVoiceCall = useCallback(() => navigation.navigate('VoiceCall', { roomId: text.text, navigation, friend }), [navigation, text.text, friend]);
  const openPlayer = useCallback(() => navigation.navigate(text.type === 'watch' ? 'PlayVideo' : 'PlayMusic', { roomId: text.text, navigation, host: user.username }), [navigation, text.type, text.text, user.username]);

  const isHighlighted = highlightedMessageId === text.id;

  return (
    <View style={styles.bubbleRowMe}>
      {shouldShowDay && (
        <View style={styles.dayContainer}>
          <Text style={styles.dayText}>{currentMessageDay}</Text>
        </View>
      )}
      <View style={styles.bubbleMeContainer}>
        <PanGestureHandler onGestureEvent={onGestureEvent} onHandlerStateChange={onHandlerStateChange}>
          <Animated.View style={{ transform: [{ translateX }] }}>
            <View style={[styles.bubbleMe, text.type !== 'text' && styles.bubbleMedia, isHighlighted && styles.highlightedBubble, text.pinned && styles.pinnedBubble]}>
              {text.is_deleted ? (
                <Text style={styles.deletedText}>Message deleted</Text>
              ) : (
                <View style={styles.bubbleContent}>
                  {text.replied_to && (
                    <TouchableOpacity onPress={() => onReplyPress(text.replied_to)}>
                      <View style={styles.replyContainerMe}>
                        <Text style={styles.replyAuthorMe}>{text.replied_to_message?.is_me ? 'You' : friend.name}</Text>
                        {text.replied_to_message?.type === 'text' ? (
                          <Text style={styles.replyTextMe}>{text.replied_to_message.text}</Text>
                        ) : (
                          <View style={styles.replyImageContainerMe}>
                            <Image source={{ uri: `https://${API_BASE_URL}${text.replied_to_message.text}` }} style={styles.replyImage} />
                            <Text style={styles.replyTextMe}>{text.replied_to_message.type}</Text>
                          </View>
                        )}
                      </View>
                    </TouchableOpacity>
                  )}
                  {editMode ? (
                    <View style={styles.editContainer}>
                      <TextInput value={editText} onChangeText={setEditText} style={styles.editInput} />
                      <TouchableOpacity onPress={handleEdit}>
                        <Text style={styles.editSave}>Save</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <>
                      {text.type === 'image' || text.type === 'video' ? (
                        <TouchableOpacity onLongPress={() => setShowOptions(true)} onPress={() => navigation.navigate('ViewAnyImage', { type: `https://${API_BASE_URL}${text.text}`, mediaType: text.type })}>
                          {text.type === 'image' ? (
                            <Image source={{ uri: `https://${API_BASE_URL}${text.text}` }} style={styles.mediaImage} />
                          ) : (
                            <Video source={{ uri: `https://${API_BASE_URL}${text.text}` }} style={styles.mediaImage} controls paused />
                          )}
                        </TouchableOpacity>
                      ) : text.type === 'audio' ? (
                        <Pressable onLongPress={() => setShowOptions(true)}>
                          <AudioPlayerT audioUrl={`https://${API_BASE_URL}${text.text}`} from="me" />
                        </Pressable>
                      ) : text.type === 'document' ? (
                        <TouchableOpacity onLongPress={() => setShowOptions(true)} onPress={() => Linking.openURL(`https://${API_BASE_URL}${text.text}`)}>
                          <Text style={styles.documentText}>Document</Text>
                        </TouchableOpacity>
                      ) : text.type === 'text' ? (
                        <Pressable onLongPress={() => setShowOptions(true)}>
                          <Text style={styles.bubbleTextMe}>
                            {text.text.split(' ').map((word, index) => (word.startsWith('@') ? <Text key={index} style={styles.mention}>{word} </Text> : `${word} `))}
                          </Text>
                        </Pressable>
                      ) : text.type === 'location' ? (
                        <TouchableOpacity onPress={openGoogleMaps}>
                          <WebView originWhitelist={['*']} source={{ html: map }} style={styles.locationMap} />
                        </TouchableOpacity>
                      ) : text.type === 'videocall' ? (
                        <TouchableOpacity style={styles.actionButton} onPress={openCameras}>
                          <Text style={styles.actionText}>Join</Text>
                        </TouchableOpacity>
                      ) : text.type === 'voicecall' ? (
                        <TouchableOpacity style={styles.actionButton} onPress={openVoiceCall}>
                          <Text style={styles.actionText}>Join</Text>
                        </TouchableOpacity>
                      ) : text.type === 'listen' || text.type === 'watch' ? (
                        <TouchableOpacity style={styles.actionButton} onPress={openPlayer}>
                          <Text style={styles.actionText}>{text.type === 'listen' ? 'Listen' : 'Watch'}</Text>
                        </TouchableOpacity>
                      ) : null}
                      <View style={styles.messageFooter}>
                        <Text style={styles.timestampMe}>{utils.formatTimeChat(text.created)}</Text>
                        {text.seen ? <Image source={ASSETS.seen} style={styles.seenIconMe} /> : <Image source={ASSETS.unseen} style={styles.unseenIconMe} />}
                      </View>
                      {text.reactions?.length > 0 && (
                        <View style={styles.reactionsContainer}>
                          {text.reactions.map((r, i) => (
                            <Text key={i} style={styles.reactionEmoji}>{r.emoji}</Text>
                          ))}
                        </View>
                      )}
                    </>
                  )}
                </View>
              )}
            </View>
          </Animated.View>
        </PanGestureHandler>
        {showOptions && (
          <View style={styles.optionsContainerMe}>
            <TouchableOpacity onPress={deleteMessage}>
              <Image source={ASSETS.del} style={styles.optionIconMe} />
            </TouchableOpacity>
            <TouchableOpacity onPress={copyToClipboard}>
              <Image source={ASSETS.copy} style={styles.optionIconMe} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setReplyingTo(text)}>
              <Image source={ASSETS.reply} style={styles.optionIconMe} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setEditMode(true)}>
              <Text style={styles.optionText}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setShowEmojiPicker(true)}>
              <Text style={styles.optionText}>React</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => onPinMessage(text.id)}>
              <Image source={ASSETS.pin} style={styles.optionIconMe} />
            </TouchableOpacity>
          </View>
        )}
      </View>
      <EmojiPicker open={showEmojiPicker} onClose={() => setShowEmojiPicker(false)} onEmojiSelected={handleReaction} />
    </View>
  );
});

// MessageBubbleFriend Component
const MessageBubbleFriend = memo(({ text, friend, typing = false, navigation, previousMessage, replyingTo, setReplyingTo, displayedDays, onReplyPress, highlightedMessageId, onPinMessage }) => {
  const user = useGlobal(state => state.user);
  const [showOptions, setShowOptions] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [token, setToken] = useState('');
  const translateX = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const fetchToken = async () => {
      const tokens = await secure.get('tokens');
      setToken(tokens?.access || '');
    };
    fetchToken();
  }, []);

  const currentMessageDay = typing ? null : utils.formatTimeDays(text.created);
  const previousMessageDay = previousMessage ? utils.formatTimeDays(previousMessage.created) : null;
  const shouldShowDay = !typing && currentMessageDay && !displayedDays.has(currentMessageDay) && currentMessageDay !== previousMessageDay;
  if (shouldShowDay) displayedDays.add(currentMessageDay);

  const copyToClipboard = useCallback(async () => {
    if (!text?.text) return;
    await Clipboard.setString(text.text);
    Toast.show('Copied to clipboard', Toast.SHORT);
  }, [text?.text]);

  const handleReaction = useCallback(async (emojiObj) => {
    const emoji = typeof emojiObj === 'object' ? emojiObj.emoji : emojiObj;
    if (!emoji || emoji.length > 255) {
      Toast.show('Invalid emoji', Toast.SHORT);
      return;
    }
    try {
      await axios.post(`https://${API_BASE_URL}/chat/messages/react/${text.id}/`, { emoji }, { headers: { Authorization: `Bearer ${token}` } });
      Toast.show('Reaction added', Toast.SHORT);
    } catch (error) {
      Toast.show('Failed to react', Toast.SHORT);
    }
  }, [text.id, token]);

  const onGestureEvent = Animated.event([{ nativeEvent: { translationX: translateX } }], { useNativeDriver: true });
  const onHandlerStateChange = (event) => {
    if (event.nativeEvent.state === State.END) {
      if (event.nativeEvent.translationX > 50) {
        setReplyingTo(text);
        Animated.timing(translateX, { toValue: 100, duration: 200, useNativeDriver: true }).start(() =>
          Animated.timing(translateX, { toValue: 0, duration: 200, useNativeDriver: true }).start()
        );
      } else {
        Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
      }
    }
  };

  const [lt, lo] = typing ? ['', ''] : (text?.text.split(' ') || ['', '']);
  const map = Map({ lt, lo });

  const openGoogleMaps = useCallback(() => Linking.openURL(Platform.select({ ios: `https://maps.apple.com/?ll=${lt},${lo}`, android: `google.navigation:q=${lt},${lo}` })), [lt, lo]);
  const openCameras = useCallback(() => navigation.navigate('VideoCall', { roomId: text.text, navigation, friend }), [navigation, text?.text, friend]);
  const openVoiceCall = useCallback(() => navigation.navigate('VoiceCall', { roomId: text.text, navigation, friend }), [navigation, text?.text, friend]);
  const openPlayer = useCallback(() => navigation.navigate(text.type === 'watch' ? 'PlayVideo' : 'PlayMusic', { roomId: text.text, navigation, host: user.username }), [navigation, text?.type, text?.text, user.username]);

  const isHighlighted = highlightedMessageId === text?.id;

  return (
    <View style={styles.bubbleRowFriend}>
      {shouldShowDay && (
        <View style={styles.dayContainer}>
          <Text style={styles.dayText}>{currentMessageDay}</Text>
        </View>
      )}
      <View style={styles.bubbleFriendContainer}>
        <View style={styles.avatarContainer}>
          <Thumbnail url={friend.thumbnail} size={35} />
        </View>
        <View style={styles.bubbleFriendWrapper}>
          <PanGestureHandler onGestureEvent={onGestureEvent} onHandlerStateChange={onHandlerStateChange}>
            <Animated.View style={{ transform: [{ translateX }] }}>
              <View style={[styles.bubbleFriend, typing || text.type !== 'text' ? styles.bubbleMedia : null, isHighlighted && styles.highlightedBubble, text.pinned && styles.pinnedBubble]}>
                {typing ? (
                  <View style={styles.typingContainer}>
                    <Animated.View style={[styles.typingDot, { animation: 'bounce 0.6s infinite' }]} />
                    <Animated.View style={[styles.typingDot, { animation: 'bounce 0.6s infinite 0.2s' }]} />
                    <Animated.View style={[styles.typingDot, { animation: 'bounce 0.6s infinite 0.4s' }]} />
                  </View>
                ) : (
                  <View style={styles.bubbleContent}>
                    {text.replied_to && (
                      <TouchableOpacity onPress={() => onReplyPress(text.replied_to)}>
                        <View style={styles.replyContainerFriend}>
                          <Text style={styles.replyAuthorFriend}>{text.replied_to_message?.is_me ? 'You' : friend.name}</Text>
                          {text.replied_to_message?.type === 'text' ? (
                            <Text style={styles.replyTextFriend}>{text.replied_to_message.text}</Text>
                          ) : (
                            <View style={styles.replyImageContainerFriend}>
                              <Image source={{ uri: `https://${API_BASE_URL}${text.replied_to_message.text}` }} style={styles.replyImage} />
                              <Text style={styles.replyTextFriend}>{text.replied_to_message.type}</Text>
                            </View>
                          )}
                        </View>
                      </TouchableOpacity>
                    )}
                    {text.type === 'text' ? (
                      <Pressable onLongPress={() => setShowOptions(true)}>
                        <Text style={styles.bubbleTextFriend}>
                          {text.text.split(' ').map((word, index) => (word.startsWith('@') ? <Text key={index} style={styles.mention}>{word} </Text> : `${word} `))}
                        </Text>
                      </Pressable>
                    ) : text.type === 'image' || text.type === 'video' ? (
                      <TouchableOpacity onLongPress={() => setShowOptions(true)} onPress={() => navigation.navigate('ViewAnyImage', { type: `https://${API_BASE_URL}${text.text}`, mediaType: text.type })}>
                        {text.type === 'image' ? (
                          <Image source={{ uri: `https://${API_BASE_URL}${text.text}` }} style={styles.mediaImageFriend} />
                        ) : (
                          <Video source={{ uri: `https://${API_BASE_URL}${text.text}` }} style={styles.mediaImageFriend} controls paused />
                        )}
                      </TouchableOpacity>
                    ) : text.type === 'audio' ? (
                      <Pressable onLongPress={() => setShowOptions(true)}>
                        <AudioPlayerT audioUrl={`https://${API_BASE_URL}${text.text}`} from="friend" />
                      </Pressable>
                    ) : text.type === 'document' ? (
                      <TouchableOpacity onLongPress={() => setShowOptions(true)} onPress={() => Linking.openURL(`https://${API_BASE_URL}${text.text}`)}>
                        <Text style={styles.documentText}>Document</Text>
                      </TouchableOpacity>
                    ) : text.type === 'location' ? (
                      <TouchableOpacity onPress={openGoogleMaps}>
                        <WebView originWhitelist={['*']} source={{ html: map }} style={styles.locationMap} />
                      </TouchableOpacity>
                    ) : text.type === 'videocall' ? (
                      <View style={styles.callContainer}>
                        <Text style={styles.callText}>Incoming Video Call</Text>
                        <TouchableOpacity style={styles.acceptButton} onPress={openCameras}>
                          <Text style={styles.actionText}>Accept</Text>
                        </TouchableOpacity>
                      </View>
                    ) : text.type === 'voicecall' ? (
                      <View style={styles.callContainer}>
                        <Text style={styles.callText}>Incoming Voice Call</Text>
                        <TouchableOpacity style={styles.acceptButton} onPress={openVoiceCall}>
                          <Text style={styles.actionText}>Accept</Text>
                        </TouchableOpacity>
                      </View>
                    ) : text.type === 'listen' || text.type === 'watch' ? (
                      <TouchableOpacity style={styles.actionButtonFriend} onPress={openPlayer}>
                        <Text style={styles.actionText}>{text.type === 'listen' ? 'Listen' : 'Watch'}</Text>
                      </TouchableOpacity>
                    ) : null}
                    <Text style={styles.timestampFriend}>{utils.formatTimeChat(text.created)}</Text>
                    {text.reactions?.length > 0 && (
                      <View style={styles.reactionsContainer}>
                        {text.reactions.map((r, i) => (
                          <Text key={i} style={styles.reactionEmoji}>{r.emoji}</Text>
                        ))}
                      </View>
                    )}
                  </View>
                )}
              </View>
            </Animated.View>
          </PanGestureHandler>
          {showOptions && !typing && (
            <View style={styles.optionsContainerFriend}>
              <TouchableOpacity onPress={copyToClipboard}>
                <Image source={ASSETS.copy} style={styles.optionIconFriend} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setReplyingTo(text)}>
                <Image source={ASSETS.reply} style={styles.optionIconFriend} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setShowEmojiPicker(true)}>
                <Text style={styles.optionText}>React</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => onPinMessage(text.id)}>
                <Image source={ASSETS.pin} style={styles.optionIconFriend} />
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
      <EmojiPicker open={showEmojiPicker} onClose={() => setShowEmojiPicker(false)} onEmojiSelected={handleReaction} />
    </View>
  );
});

// MessageBubble Component
const MessageBubble = memo(({ index, message, friend, navigation, connectionId, previousMessage, setReplyingTo, replyingTo, displayedDays, onReplyPress, highlightedMessageId, onPinMessage, onEditMessage }) => {
  const [showTyping, setShowTyping] = useState(false);
  const messagesTyping = useGlobal(state => state.messagesTyping);

  useEffect(() => {
    if (index !== 0) return;
    if (!messagesTyping) {
      setShowTyping(false);
      return;
    }
    setShowTyping(true);
    const interval = setInterval(() => {
      const now = new Date().getTime();
      if (now - messagesTyping > 10000) setShowTyping(false);
    }, 1000);
    return () => clearInterval(interval);
  }, [messagesTyping, index]);

  if (index === 0) {
    if (showTyping) {
      const dummyMessage = { id: 'typing-placeholder', text: '', type: 'text', created: new Date().toISOString(), is_me: false, seen: false, is_deleted: false, pinned: false, incognito: false };
      return <MessageBubbleFriend friend={friend} text={dummyMessage} typing={true} displayedDays={displayedDays} onReplyPress={onReplyPress} highlightedMessageId={highlightedMessageId} onPinMessage={onPinMessage} />;
    }
    return null;
  }

  return message.is_me ? (
    <MessageBubbleMe
      text={message}
      navigation={navigation}
      previousMessage={previousMessage}
      setReplyingTo={setReplyingTo}
      replyingTo={replyingTo}
      friend={friend}
      displayedDays={displayedDays}
      onReplyPress={onReplyPress}
      highlightedMessageId={highlightedMessageId}
      onPinMessage={onPinMessage}
      onEditMessage={onEditMessage}
    />
  ) : (
    <MessageBubbleFriend
      text={message}
      friend={friend}
      navigation={navigation}
      previousMessage={previousMessage}
      setReplyingTo={setReplyingTo}
      replyingTo={replyingTo}
      displayedDays={displayedDays}
      onReplyPress={onReplyPress}
      highlightedMessageId={highlightedMessageId}
      onPinMessage={onPinMessage}
    />
  );
});

// MessageInput Component
const MessageInput = memo(({ message, setMessage, onSend, connectionId, navigation, user, friend, isGroup, setIncognito, incognito, setDisappearing, disappearing }) => {
  const [height, setHeight] = useState(48);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [recorded, setRecorded] = useState('');
  const [openPlayer, setOpenPlayer] = useState(false);
  const [openMap, setOpenMap] = useState(false);
  const [loading, setLoading] = useState(false);
  const [lt, setLt] = useState('');
  const [lo, setLo] = useState('');
  const [showOptions, setShowOptions] = useState(false);
  const [showDisappearingOptions, setShowDisappearingOptions] = useState(false);
  const optionsAnim = useRef(new Animated.Value(0)).current;
  const messageSend = useGlobal(state => state.messageSend);
  const textInputRef = useRef(null);

  const pulseAnim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (isRecording) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 500, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1); // Reset scale
    }
  }, [isRecording]);


  useEffect(() => {
    Animated.timing(optionsAnim, { toValue: showOptions ? 1 : 0, duration: 200, easing: Easing.ease, useNativeDriver: true }).start();
  }, [showOptions]);

  const requestMicrophonePermission = async () => {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
      if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
        Alert.alert('Permission denied', 'Microphone access is required for recording audio.');
        return false;
      }
    }
    return true;
  };

  const startRecording = useCallback(async () => {
    const hasPermission = await requestMicrophonePermission();
    if (!hasPermission) return;
    const netInfo = await NetInfo.fetch();
    if (!netInfo.isConnected) {
      Toast.show('No internet connection. Recording queued.', Toast.LONG);
      return;
    }
    try {
      await audioRecorderPlayer.startRecorder();
      setIsRecording(true);
    } catch (error) {
      Toast.show('Recording failed', Toast.SHORT);
    }
  }, []);

  const stopRecording = useCallback(async () => {
    try {
      const result = await audioRecorderPlayer.stopRecorder();
      audioRecorderPlayer.removeRecordBackListener();
      setRecorded(result);
      setIsRecording(false);
      setOpenPlayer(true);
    } catch (error) {
      Toast.show('Recording failed', Toast.SHORT);
    }
  }, []);

  const uploadAudio = useCallback(async (uri) => {
    if (!uri) return;
    setLoading(true);
    const netInfo = await NetInfo.fetch();
    if (!netInfo.isConnected) {
      Toast.show('No internet connection. Audio queued.', Toast.LONG);
      setOpenPlayer(false);
      setLoading(false);
      return;
    }
    const formData = new FormData();
    formData.append('audio', { uri, type: 'audio/mp4', name: 'rec.mp4' });
    try {
      const token = (await secure.get('tokens'))?.access;
      const response = await axios.post(`https://${API_BASE_URL}/chat/audio/`, formData, {
        headers: { 'Content-Type': 'multipart/form-data', Authorization: `Bearer ${token}` },
      });
      messageSend(connectionId, response.data.audio, 'audio', null, isGroup, incognito, disappearing);
      setOpenPlayer(false);
      Toast.show('Audio sent', Toast.SHORT);
    } catch (error) {
      Toast.show('Failed to send audio', Toast.SHORT);
    } finally {
      setLoading(false);
    }
  }, [connectionId, messageSend, isGroup, incognito, disappearing]);

  const startPlaying = useCallback(async () => {
    try {
      setIsPlaying(true);
      await audioRecorderPlayer.startPlayer(recorded);
      audioRecorderPlayer.addPlayBackListener(e => {
        if (e.currentPosition === e.duration) {
          setIsPlaying(false);
          audioRecorderPlayer.stopPlayer();
        }
      });
    } catch (error) {
      Toast.show('Playback failed', Toast.SHORT);
    }
  }, [recorded]);

  const stopPlaying = useCallback(async () => {
    await audioRecorderPlayer.stopPlayer();
    audioRecorderPlayer.removePlayBackListener();
    setIsPlaying(false);
  }, []);

  const selectMedia = useCallback(async (mediaType) => {
    const maxSizes = { image: 10 * 1024 * 1024, video: 100 * 1024 * 1024, document: 50 * 1024 * 1024, audio: 10 * 1024 * 1024 };
    const allowedTypes = {
      image: ['image/jpeg', 'image/png', 'image/gif'],
      video: ['video/mp4', 'video/mpeg', 'video/quicktime'],
      document: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    };

    launchImageLibrary({ mediaType: mediaType === 'document' ? 'mixed' : mediaType, includeBase64: false }, async response => {
      if (response.didCancel || response.errorCode) return;
      const file = response.assets?.[0];
      if (!file) return;

      if (file.fileSize > maxSizes[mediaType]) {
        Toast.show(`File size exceeds ${maxSizes[mediaType] / (1024 * 1024)}MB limit`, Toast.LONG);
        return;
      }

      if (!allowedTypes[mediaType]?.includes(file.type)) {
        Toast.show(`Unsupported file type for ${mediaType}`, Toast.LONG);
        return;
      }

      setLoading(true);
      try {
        let compressedFile = file;
        if (mediaType !== 'document') {
          const compressedImage = await ImageResizer.createResizedImage(file.uri, 1024, 1024, 'JPEG', 70);
          compressedFile = { uri: compressedImage.uri, type: file.type || 'image/jpeg', name: file.fileName || `media_${Date.now()}.jpg` };
        }
        navigation.navigate('ViewMedia', { media: compressedFile, connectionId, mediaType, incognito, disappearing });
      } catch (error) {
        Toast.show('Failed to process media', Toast.SHORT);
      } finally {
        setLoading(false);
      }
    });
  }, [navigation, connectionId, incognito, disappearing]);

  const requestCameraPermission = useCallback(async () => {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA);
      if (granted === PermissionsAndroid.RESULTS.GRANTED) handleLaunchCamera();
      else Alert.alert('Permission denied', 'Camera access is required.');
    } else handleLaunchCamera();
  }, []);

  const handleLaunchCamera = useCallback(() => {
    launchCamera({ mediaType: 'photo', saveToPhotos: true }, async response => {
      if (response.didCancel || response.errorCode) return;
      const file = response.assets?.[0];
      if (!file || file.fileSize > 10 * 1024 * 1024) {
        Toast.show('Image exceeds 10MB limit', Toast.LONG);
        return;
      }
      setLoading(true);
      try {
        const compressedImage = await ImageResizer.createResizedImage(file.uri, 1024, 1024, 'JPEG', 70);
        const compressedFile = { uri: compressedImage.uri, type: 'image/jpeg', name: file.fileName || `image_${Date.now()}.jpg` };
        navigation.navigate('ViewMedia', { media: compressedFile, connectionId, mediaType: 'image', incognito, disappearing });
      } catch (error) {
        Toast.show('Failed to process image', Toast.SHORT);
      } finally {
        setLoading(false);
      }
    });
  }, [navigation, connectionId, incognito, disappearing]);

  const requestLocationPermission = async () => {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
      if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
        Alert.alert('Permission denied', 'Location access is required.');
        return false;
      }
    }
    return true;
  };

  const getLocation = useCallback(async () => {
    const hasPermission = await requestLocationPermission();
    if (!hasPermission) return;
    Geolocation.getCurrentPosition(
      position => {
        const { latitude, longitude } = position.coords;
        setLt(latitude.toString());
        setLo(longitude.toString());
        setOpenMap(true);
        setMessage(`${latitude} ${longitude}`);
      },
      () => Toast.show('Unable to fetch location', Toast.SHORT),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  }, []);

  const onSendLocation = useCallback(() => {
    const cleaned = message.trim();
    if (!cleaned) return;
    messageSend(connectionId, cleaned, 'location', null, isGroup, incognito, disappearing);
    setMessage('');
    setOpenMap(false);
    Toast.show('Location sent', Toast.SHORT);
  }, [message, connectionId, messageSend, isGroup, incognito, disappearing]);

  const generateID = useCallback(() => {
    return Array.from({ length: 6 }, () => 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'.charAt(Math.floor(Math.random() * 62))).join('');
  }, []);

  const openVideoCall = useCallback(() => {
    const id = generateID();
    messageSend(connectionId, id, 'videocall', null, isGroup, incognito, disappearing);
    navigation.navigate('VideoCall', { roomId: id, friend, navigation, isGroup });
  }, [connectionId, friend, navigation, messageSend, isGroup, incognito, disappearing]);

  const openVoiceCall = useCallback(() => {
    const id = generateID();
    messageSend(connectionId, id, 'voicecall', null, isGroup, incognito, disappearing);
    navigation.navigate('VoiceCall', { roomId: id, friend, navigation, isGroup });
  }, [connectionId, friend, navigation, messageSend, isGroup, incognito, disappearing]);

  const map = Map({ lt, lo });

  return (
    <View style={styles.inputContainer}>
      {openMap && (
        <View style={styles.mapModal}>
          <WebView originWhitelist={['*']} source={{ html: map }} style={styles.fullMap} />
          <TouchableOpacity style={styles.sendButton} onPress={onSendLocation}>
            <Text style={styles.sendButtonText}>Share Location</Text>
          </TouchableOpacity>
        </View>
      )}
      <View style={styles.inputRow}>
        {openPlayer ? (
          <View style={styles.audioPlayerContainer}>
            <TouchableOpacity onPress={isPlaying ? stopPlaying : startPlaying}>
              {isPlaying ? <Image source={ASSETS.pause} style={styles.audioIcon} /> : <Image source={ASSETS.play} style={styles.audioIcon} />}
            </TouchableOpacity>
            <TouchableOpacity onPress={() => uploadAudio(recorded)}>
              <Image source={ASSETS.sendMessageIcon} style={styles.sendMessageIcon} />
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {!message && (
              <TouchableOpacity style={styles.plusButton} onPress={() => setShowOptions(!showOptions)}>
                <Image source={ASSETS.plus} style={styles.plusIcon} />
              </TouchableOpacity>
            )}
            <TextInput
              ref={textInputRef}
              multiline
              placeholder="Type a message"
              value={message}
              onChangeText={setMessage}
              onContentSizeChange={e => setHeight(Math.min(e.nativeEvent.contentSize.height, 120))}
              style={[styles.input, { height: Math.max(48, height) }]}
            />
            {!message ? (
  <TouchableOpacity onPress={isRecording ? stopRecording : startRecording}>
    <Animated.View style={{ transform: [{ scale: isRecording ? pulseAnim : 1 }] }}>
      <FontAwesomeIcon icon={isRecording ? 'stop' : 'microphone'} size={24} color="#075E54" />
    </Animated.View>
  </TouchableOpacity>
) : (
  <TouchableOpacity onPress={onSend} style={styles.sendButton}>
    <Image source={ASSETS.sendMessageIcon} style={styles.sendMessageIcon} />
  </TouchableOpacity>
)}
          </>
        )}
      </View>
      <Animated.View style={[styles.optionsMenu, { opacity: optionsAnim, transform: [{ translateY: optionsAnim.interpolate({ inputRange: [0, 1], outputRange: [100, 0] }) }] }]}>
        <TouchableOpacity style={styles.optionItem} onPress={requestCameraPermission}>
          <Image source={ASSETS.camera} style={styles.optionIcon} />
          <Text style={styles.optionText}>Camera</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.optionItem} onPress={() => selectMedia('image')}>
          <Image source={ASSETS.gallery} style={styles.optionIcon} />
          <Text style={styles.optionText}>Image</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.optionItem} onPress={() => selectMedia('document')}>
          <Image source={ASSETS.gallery} style={styles.optionIcon} />
          <Text style={styles.optionText}>Document</Text>
        </TouchableOpacity>
      </Animated.View>
      {showDisappearingOptions && (
        <View style={styles.disappearingOptions}>
          <TouchableOpacity onPress={() => { setDisappearing(0); setShowDisappearingOptions(false); }}>
            <Text style={styles.optionText}>Off</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { setDisappearing(3600); setShowDisappearingOptions(false); }}>
            <Text style={styles.optionText}>1 Hour</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { setDisappearing(86400); setShowDisappearingOptions(false); }}>
            <Text style={styles.optionText}>1 Day</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { setDisappearing(604800); setShowDisappearingOptions(false); }}>
            <Text style={styles.optionText}>1 Week</Text>
          </TouchableOpacity>
        </View>
      )}
      {loading && <ActivityIndicator size="small" color="#075E54" style={styles.loadingIndicator} />}
    </View>
  );
});

// ReplyingToPreview Component
const ReplyingToPreview = memo(({ replyingTo, friend, setReplyingTo }) => {
  const slideAnim = useRef(new Animated.Value(-300)).current;

  useEffect(() => {
    Animated.timing(slideAnim, { toValue: 0, duration: 300, easing: Easing.ease, useNativeDriver: true }).start();
  }, []);

  return (
    <Animated.View style={[styles.replyPreview, { transform: [{ translateX: slideAnim }] }]}>
      <View style={styles.replyContent}>
        <Text style={styles.replyAuthor}>{replyingTo.is_me ? 'You' : friend.name}</Text>
        {replyingTo.type === 'text' ? (
          <Text style={styles.replyText}>{replyingTo.text}</Text>
        ) : (
          <View style={styles.imagePreview}>
            <Image source={{ uri: `https://${API_BASE_URL}${replyingTo.text}` }} style={styles.previewImage} />
          </View>
        )}
      </View>
      <TouchableOpacity onPress={() => setReplyingTo(null)} style={styles.closeButton}>
        <Image source={ASSETS.close} style={styles.closeIcon} />
      </TouchableOpacity>
    </Animated.View>
  );
});

// MessagesScreen Component
const MessagesScreen = ({ navigation, route }) => {
  const [showScrollToBottom, setShowScrollToBottom] = useState(false);
  const [message, setMessage] = useState('');
  const [replyingTo, setReplyingTo] = useState(null);
  const [displayedDays] = useState(new Set());
  const [highlightedMessageId, setHighlightedMessageId] = useState(null);
  const [incognito, setIncognito] = useState(false);
  const [disappearing, setDisappearing] = useState(0);
  const flashListRef = useRef(null);
  const messagesList = useGlobal(state => state.messagesList);
  const messagesNext = useGlobal(state => state.messagesNext);
  const messageList = useGlobal(state => state.messageList);
  const messageSend = useGlobal(state => state.messageSend);
  const messageType = useGlobal(state => state.messageType);
  const user = useGlobal(state => state.user);
  const [hasMarkedSeen, setHasMarkedSeen] = useState(false);
  const [mutedChats, setMutedChats] = useState([]);
  const connectionId = route.params.id;
  const friend = route.params.friend;
  const isGroup = route.params.isGroup || false;
  const groupAdmins = route.params.groupAdmins || [];

  const markMessagesSeen = useCallback(async () => {
    if (hasMarkedSeen) return;
    try {
      const token = (await secure.get('tokens'))?.access;
      const response = await axios.post(`https://${API_BASE_URL}/chat/messages/mark-seen/${connectionId}/`, {}, { headers: { Authorization: `Bearer ${token}` } });
      if (response.status === 200) {
        setHasMarkedSeen(true);
        useGlobal.setState(state => ({ unreadCounts: { ...state.unreadCounts, [connectionId]: 0 } }));
      }
    } catch (error) {
      utils.error('Error marking messages seen:', error);
    }
  }, [connectionId, hasMarkedSeen]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', markMessagesSeen);
    messageList(connectionId);
    return unsubscribe;
  }, [navigation, markMessagesSeen, connectionId, messageList]);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: () => (
        <MessageHeader
          friend={friend}
          navigation={navigation}
          connectionId={connectionId}
          user={user}
          isGroup={isGroup}
          groupAdmins={groupAdmins}
          onMuteToggle={() => {
            const updatedMuted = mutedChats.includes(connectionId) ? mutedChats.filter(id => id !== connectionId) : [...mutedChats, connectionId];
            setMutedChats(updatedMuted);
            Toast.show(updatedMuted.includes(connectionId) ? 'Chat muted' : 'Chat unmuted', Toast.SHORT);
          }}
          onBlockUser={async () => {
            const token = (await secure.get('tokens'))?.access;
            axios.post(`https://${API_BASE_URL}/chat/block/${friend.username}/`, {}, { headers: { Authorization: `Bearer ${token}` } })
              .then(() => Toast.show('User blocked', Toast.SHORT))
              .catch(() => Toast.show('Failed to block user', Toast.SHORT));
          }}
          onReportUser={async () => {
            const token = (await secure.get('tokens'))?.access;
            axios.post(`https://${API_BASE_URL}/chat/report/${friend.username}/`, {}, { headers: { Authorization: `Bearer ${token}` } })
              .then(() => Toast.show('User reported', Toast.SHORT))
              .catch(() => Toast.show('Failed to report user', Toast.SHORT));
          }}
        />
      ),
    });
  }, [friend, navigation, connectionId, user, isGroup, groupAdmins, mutedChats]);

  const scrollToRepliedMessage = useCallback((replied_to) => {
    const index = messagesList.findIndex(m => m.id === replied_to) + 1;
    if (index > 0 && flashListRef.current) {
      flashListRef.current.scrollToIndex({ index, animated: true, viewPosition: 0.5 });
      setHighlightedMessageId(replied_to);
      setTimeout(() => setHighlightedMessageId(null), 2000);
    } else {
      Toast.show('Message not found', Toast.SHORT);
    }
  }, [messagesList]);

  const handleSend = useCallback(async () => {
    const cleaned = message.trim();
    if (!cleaned) return;
    const netInfo = await NetInfo.fetch();
    if (!netInfo.isConnected) {
      Toast.show('No internet connection. Message queued.', Toast.LONG);
      return;
    }
    messageSend(connectionId, cleaned, 'text', replyingTo?.id, isGroup, incognito, disappearing);
    setMessage('');
    setReplyingTo(null);
    Toast.show('Message sent', Toast.SHORT);
  }, [message, connectionId, replyingTo, messageSend, isGroup, incognito, disappearing]);

  const handleType = useCallback((value) => {
    setMessage(value);
    messageType(friend.username);
  }, [friend.username, messageType]);

  const handleScroll = useCallback((event) => setShowScrollToBottom(event.nativeEvent.contentOffset.y > 50), []);

  const scrollToBottom = useCallback(() => {
    flashListRef.current?.scrollToOffset({ offset: 0, animated: true });
    setShowScrollToBottom(false);
  }, []);

  const handlePinMessage = useCallback(async (messageId) => {
    const token = (await secure.get('tokens'))?.access;
    axios.post(`https://${API_BASE_URL}/chat/messages/pin/${messageId}/`, {}, { headers: { Authorization: `Bearer ${token}` } })
      .then(() => Toast.show('Message pinned', Toast.SHORT))
      .catch(() => Toast.show('Failed to pin message', Toast.SHORT));
  }, []);

  const handleEditMessage = useCallback((messageId, newText) => {
    const updatedMessages = messagesList.map(m => m.id === messageId ? { ...m, text: newText } : m);
    useGlobal.setState({ messagesList: updatedMessages });
  }, [messagesList]);

  const renderItem = useCallback(
    ({ item, index }) => (
      <MessageBubble
        index={index}
        message={item}
        friend={friend}
        navigation={navigation}
        connectionId={connectionId}
        previousMessage={messagesList[index + 1]}
        setReplyingTo={setReplyingTo}
        replyingTo={replyingTo}
        displayedDays={displayedDays}
        onReplyPress={scrollToRepliedMessage}
        highlightedMessageId={highlightedMessageId}
        onPinMessage={handlePinMessage}
        onEditMessage={handleEditMessage}
      />
    ),
    [messagesList, replyingTo, friend, connectionId, navigation, displayedDays, scrollToRepliedMessage, highlightedMessageId, handlePinMessage, handleEditMessage]
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.listContainer}>
        <FlashList
          ref={flashListRef}
          data={[{ id: 'header-placeholder' }, ...messagesList]}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          inverted
          estimatedItemSize={100}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          onEndReached={() => messagesNext && messageList(connectionId, messagesNext)}
          ListFooterComponent={messagesNext ? <ActivityIndicator size="small" color="#075E54" /> : null}
          automaticallyAdjustKeyboardInsets
          contentContainerStyle={styles.listContent}
        />
        {replyingTo && <ReplyingToPreview replyingTo={replyingTo} friend={friend} setReplyingTo={setReplyingTo} />}
        {!replyingTo && showScrollToBottom && (
          <TouchableOpacity style={styles.scrollButton} onPress={scrollToBottom}>
            <Image source={ASSETS.down} style={styles.scrollButtonImage} />
          </TouchableOpacity>
        )}
      </View>
      <MessageInput
        message={message}
        setMessage={handleType}
        onSend={handleSend}
        connectionId={connectionId}
        navigation={navigation}
        user={user}
        friend={friend}
        isGroup={isGroup}
        setIncognito={setIncognito}
        incognito={incognito}
        setDisappearing={setDisappearing}
        disappearing={disappearing}
      />
    </SafeAreaView>
  );
};

// Updated Styles with Proper Alignment
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ECE5DD' },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(255, 253, 231, 1)',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    // backgroundColor:'red',
    right:40
  },
  headerTextContainer: {
    marginLeft: 12,
  },
  headerName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    color:'black'
  },
  onlineStatus: {
    color: 'green',
    fontSize: 12,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    left:13,
    
  },
  headerIcon: {
    marginHorizontal: 12,
  },
  menuContent: {
    backgroundColor: 'grey',
    borderRadius: 8,
    elevation: 4,
    top:30
  },
  menuItemText: {
    color: 'white',
    fontSize: 16,
  },
  menuDivider: {
    backgroundColor: '#ddd',
  },
  dayContainer: {
    alignSelf: 'center',
    marginVertical: 10,
  },
  dayText: {
    fontSize: 12,
    color: '#666',
    backgroundColor: '#fff',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 12,
    elevation: 2,
  },
  bubbleRowMe: {
    width: '100%',
    marginVertical: 4,
    alignItems: 'flex-end',
    paddingHorizontal: 10,
  },
  bubbleMeContainer: {
    flexDirection: 'column',
    alignItems: 'flex-end',
    maxWidth: '80%',
  },
  bubbleMe: {
    backgroundColor: '#DCF8C6',
    borderRadius: 12,
    padding: 10,
    elevation: 0,
  },
  bubbleMedia: {
    backgroundColor: 'transparent',
    padding: 0,
  },
  highlightedBubble: {
    backgroundColor: '#FFF9C4',
  },
  pinnedBubble: {
    borderWidth: 2,
    borderColor: '#075E54',
  },
  bubbleContent: {
    flexDirection: 'column',
  },
  bubbleTextMe: {
    color: '#333',
    fontSize: 16,
    lineHeight: 20,
  },
  replyContainerMe: {
    backgroundColor: '#C8E6C9',
    padding: 8,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderColor: '#075E54',
  },
  replyAuthorMe: {
    color: '#075E54',
    fontWeight: '600',
    fontSize: 14,
  },
  replyTextMe: {
    color: '#555',
    fontSize: 14,
  },
  replyImageContainerMe: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 5,
  },
  replyImage: {
    height: 40,
    width: 40,
    borderRadius: 4,
    marginRight: 8,
  },
  mediaImage: {
    height: 200,
    width: 150,
    borderRadius: 8,
  },
  documentText: {
    color: '#333',
    fontSize: 16,
  },
  locationMap: {
    height: 120,
    width: 150,
    borderRadius: 8,
  },
  actionButton: {
    backgroundColor: '#075E54',
    padding: 8,
    borderRadius: 20,
    alignItems: 'center',
  },
  actionText: {
    color: '#fff',
    fontSize: 14,
  },
  messageFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 4,
  },
  timestampMe: {
    color: '#666',
    fontSize: 12,
    marginRight: 4,
  },
  seenIconMe: {
    height: 12,
    width: 12,
    tintColor: '#34B7F1',
  },
  unseenIconMe: {
    height: 12,
    width: 12,
    tintColor: '#999',
  },
  optionsContainerMe: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 6,
    elevation: 2,
    marginTop: 4,
  },
  optionIconMe: {
    height: 20,
    width: 20,
    marginHorizontal: 6,
  },
  editContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
  },
  editInput: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 8,
    fontSize: 16,
    color: '#333',
  },
  editSave: {
    color: '#075E54',
    fontSize: 14,
    marginLeft: 8,
  },
  reactionsContainer: {
    flexDirection: 'row',
    marginTop: 4,
    padding: 4,
    backgroundColor: '#f0f0f0',
    borderRadius: 12,
  },
  reactionEmoji: {
    fontSize: 16,
    marginHorizontal: 4,
  },
  mention: {
    color: '#075E54',
    fontWeight: 'bold',
  },
  bubbleRowFriend: {
    width: '100%',
    marginVertical: 4,
    alignItems: 'flex-start',
    paddingHorizontal: 10,
  },
  bubbleFriendContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    maxWidth: '80%',
  },
  avatarContainer: {
    marginRight: 8,
    marginTop: 4,
  },
  bubbleFriendWrapper: {
    flexDirection: 'column',
    alignItems: 'flex-start',
  },
  bubbleFriend: {
    backgroundColor: 'rgba(255, 253, 231, 1)',
    borderRadius: 12,
    padding: 10,
    elevation: 0,
  },
  bubbleTextFriend: {
    color: '#333',
    fontSize: 16,
    lineHeight: 20,
  },
  replyContainerFriend: {
    backgroundColor: '#F5F5F5',
    padding: 8,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderColor: '#666',
  },
  replyAuthorFriend: {
    color: '#666',
    fontWeight: '600',
    fontSize: 14,
  },
  replyTextFriend: {
    color: '#555',
    fontSize: 14,
  },
  replyImageContainerFriend: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 5,
  },
  mediaImageFriend: {
    height: 200,
    width: 150,
    borderRadius: 8,
  },
  callContainer: {
    padding: 8,
  },
  callText: {
    color: '#333',
    fontSize: 14,
  },
  acceptButton: {
    backgroundColor: '#075E54',
    padding: 8,
    borderRadius: 20,
    marginTop: 6,
    alignItems: 'center',
  },
  actionButtonFriend: {
    backgroundColor: '#FF5722',
    padding: 8,
    borderRadius: 20,
    alignItems: 'center',
  },
  timestampFriend: {
    color: '#666',
    fontSize: 12,
    marginTop: 4,
  },
  optionsContainerFriend: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 6,
    elevation: 2,
    marginTop: 4,
  },
  optionIconFriend: {
    height: 20,
    width: 20,
    marginHorizontal: 6,
  },
  typingContainer: {
    flexDirection: 'row',
    paddingVertical: 5,
  },
  typingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#999',
    marginHorizontal: 2,
  },
  inputContainer: {
    backgroundColor: 'rgba(255, 253, 231, 1)',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 253, 231, 1)',
    borderRadius: 24,
    paddingHorizontal: 10,
    borderWidth:0.1,
    borderColor:'black'
  },
  plusButton: {
    padding: 10,
   
  },
  plusIcon: {
    height: 24,
    width: 24,
    tintColor: '#075E54',
  },
  input: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 10,
    fontSize: 16,
    color: '#333',
    borderRadius: 24,
  },
  sendButton: {
    padding: 10,
  },
  sendMessageIcon: {
    height: 24,
    width: 24,
    tintColor: '#075E54',
  },
  audioPlayerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    paddingVertical: 8,
  },
  audioIcon: {
    height: 24,
    width: 24,
    marginHorizontal: 10,
  },
  optionsMenu: {
    position: 'absolute',
    bottom: 70,
    left: 10,
    backgroundColor: 'grey',
    borderRadius: 8,
    padding: 10,
    elevation: 4,
    flexDirection: 'row',
  },
  optionItem: {
    alignItems: 'center',
    marginHorizontal: 10,
  },
  optionIcon: {
    height: 24,
    width: 30,
    tintColor: 'white',
  },
  optionText: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
  mapModal: {
    height: '90%',
    width: '100%',
    backgroundColor: '#fff',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  fullMap: {
    flex: 1,
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
  listContainer: {
    flex: 1,
  },
  listContent: {
    paddingVertical: 10,
  },
  scrollButton: {
    position: 'absolute',
    bottom: 80,
    right: 15,
    backgroundColor: '#075E54',
    borderRadius: 20,
    padding: 10,
    elevation: 0,
  },
  scrollButtonImage: {
    height: 20,
    width: 20,
    tintColor: '#fff',
  },
  replyPreview: {
    backgroundColor: '#F5F5F5',
    padding: 10,
    borderLeftWidth: 4,
    borderColor: '#075E54',
    borderRadius: 8,
    marginHorizontal: 10,
    marginBottom: 5,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 1,
  },
  replyContent: {
    flex: 1,
  },
  replyAuthor: {
    fontWeight: '600',
    fontSize: 14,
    color: '#075E54',
  },
  replyText: {
    fontSize: 14,
    color: '#555',
  },
  imagePreview: {
    marginTop: 4,
  },
  previewImage: {
    height: 40,
    width: 40,
    borderRadius: 4,
  },
  closeButton: {
    padding: 5,
  },
  closeIcon: {
    height: 20,
    width: 20,
    tintColor: '#666',
  },
  deletedText: {
    color: '#999',
    fontStyle: 'italic',
    fontSize: 14,
  },
  disappearingOptions: {
    position: 'absolute',
    bottom: 60,
    left: 10,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 10,
    elevation: 4,
  },
  loadingIndicator: {
    marginTop: 8,
  },
});

export default MessagesScreen;