export const DEMO_VIDEOS = [
  '9pdj4iJDcXs', // Sample video ID 1
  'dQw4w9WgXcQ', // Sample video ID 2
  'EJXDMwGWhoA', // Sample video ID 3
];