import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
  Image,
} from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
  faComment,
  faRetweet,
  faHeart,
  faShare,
  faPencil,
  faPlay,
  faPause,
} from '@fortawesome/free-solid-svg-icons';
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ADDRESS } from '../core/api';
import secure from '../core/secure';
import useGlobal from '../core/global';
import utils from '../core/utils';
import { launchImageLibrary } from 'react-native-image-picker';
import ImageResizer from 'react-native-image-resizer';
import Video from 'react-native-video';
import moment from 'moment';
import Thumbnail from '../common/Thumbnail';

function ProfileImage() {
  const uploadThumbnail = useGlobal(state => state.uploadThumbnail);
  const user = useGlobal(state => state.user);
  const [uploading, setUploading] = useState(false);

  const handleImageUpload = useCallback(async (file) => {
    try {
      setUploading(true);
      const compressedImage = await ImageResizer.createResizedImage(
        file.uri,
        800,  // maxWidth
        800,  // maxHeight
        'JPEG',  // compressFormat
        70,     // quality
        0,      // rotation
        null,   // outputPath
        false   // keepMeta
      );
      await uploadThumbnail({
        ...file,
        uri: compressedImage.uri,
        base64: `data:image/jpeg;base64,${compressedImage.base64}`,
      });
    } catch (error) {
      utils.toast('Error compressing or uploading image');
      console.error('Image upload error:', error);
    } finally {
      setUploading(false);
    }
  }, [uploadThumbnail]);

  return (
    <TouchableOpacity
      style={{ marginBottom: 20 }}
      onPress={() => {
        launchImageLibrary({ includeBase64: true }, (response) => {
          if (response.didCancel) return;
          const file = response.assets[0];
          handleImageUpload(file);
        });
      }}
      disabled={uploading}
    >
      <Thumbnail
        url={user.thumbnail}
        size={180}
      />
      {uploading && (
        <View style={styles.uploadOverlay}>
          <ActivityIndicator size="large" color="#fff" />
        </View>
      )}
      <View style={styles.editIconContainer}>
        <FontAwesomeIcon icon={faPencil} size={15} color="white" />
      </View>
    </TouchableOpacity>
  );
}

function EditModal({ visible, initialValue, onClose, onSave, isBio = false }) {
  const [value, setValue] = useState(initialValue);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    try {
      setLoading(true);
      await onSave(value);
      onClose();
    } catch (error) {
      utils.toast('Error saving changes');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <TextInput
            style={styles.input}
            value={value}
            onChangeText={setValue}
            multiline={isBio}
            placeholder={isBio ? 'Enter your bio' : 'Enter your name'}
            placeholderTextColor="#888"
            autoFocus={true}
          />
          <View style={styles.modalActions}>
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={onClose}
              disabled={loading}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.saveButton}
              onPress={handleSave}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Save</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function ProfileLogout() {
  const logout = useGlobal(state => state.logout);
  return (
    <TouchableOpacity
      style={styles.logoutButton}
      onPress={logout}
    >
      <Text style={styles.logoutButtonText}>Log Out</Text>
    </TouchableOpacity>
  );
}

const Post = React.memo(({ post, onLike, onRetweet, onAddComment }) => {
  const [commentText, setCommentText] = useState('');
  const videoRef = useRef(null);
  const [videoPaused, setVideoPaused] = useState(true);
  const navigation = useNavigation();

  const handleCommentSubmit = useCallback(() => {
    if (commentText.trim()) {
      onAddComment(post.id, commentText);
      setCommentText('');
    }
  }, [commentText, post.id, onAddComment]);

  return (
    <View style={styles.postContainer}>
      <Image
        source={{ uri: post.user?.thumbnail || 'https://via.placeholder.com/48' }}
        style={styles.avatar}
      />
      <View style={styles.postContent}>
        <TouchableOpacity onPress={() => navigation.navigate('PostDetail', { post })}>
          <View style={styles.postHeader}>
            <Text style={styles.userName}>{post.user?.username || 'Unknown'}</Text>
            <Text style={styles.timestamp}>· {moment(post.created).fromNow()}</Text>
          </View>
          <Text style={styles.postText}>{post.content || ''}</Text>
          {post.media?.length > 0 && (
            <View style={styles.mediaContainer}>
              {post.media.map((media, index) => (
                <View key={`${media.id || 'media'}-${index}`}>
                  {media.media_type === 'image' ? (
                    <Image
                      source={{ uri: media.file || 'https://via.placeholder.com/150' }}
                      style={styles.mediaImage}
                      onError={e => utils.log('Image load failed:', media.file, e.nativeEvent)}
                    />
                  ) : (
                    <View style={styles.videoContainer}>
                      <Video
                        ref={videoRef}
                        source={{ uri: media.file || '' }}
                        style={styles.video}
                        paused={videoPaused}
                        resizeMode="cover"
                        repeat
                        controls={false}
                        onError={e => utils.log('Video error:', e)}
                      />
                      <TouchableOpacity
                        style={styles.playButton}
                        onPress={() => setVideoPaused(!videoPaused)}
                      >
                        <FontAwesomeIcon
                          icon={videoPaused ? faPlay : faPause}
                          size={24}
                          color="white"
                        />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              ))}
            </View>
          )}
        </TouchableOpacity>
        <View style={styles.postActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => navigation.navigate('PostDetail', { post })}
          >
            <FontAwesomeIcon icon={faComment} color="#666" />
            <Text style={styles.actionCount}>{post.comments?.length || 0}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => onRetweet(post.id)}
          >
            <FontAwesomeIcon
              icon={faRetweet}
              color={post.is_retweeted ? '#00BA7C' : '#666'}
            />
            <Text style={styles.actionCount}>{post.retweets_count || 0}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => onLike(post.id)}
          >
            <FontAwesomeIcon
              icon={faHeart}
              color={post.is_liked ? '#F91880' : '#666'}
            />
            <Text style={styles.actionCount}>{post.likes_count || 0}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() =>
              Share.share({
                message: `${post.user?.username || 'User'}: ${post.content || ''}`,
              })
            }
          >
            <FontAwesomeIcon icon={faShare} color="#666" />
          </TouchableOpacity>
        </View>
        <View style={styles.commentContainer}>
          <TextInput
            style={styles.commentInput}
            placeholder="Write a comment..."
            placeholderTextColor="#666"
            value={commentText}
            onChangeText={setCommentText}
            onSubmitEditing={handleCommentSubmit}
          />
          <TouchableOpacity onPress={handleCommentSubmit}>
            <Text style={styles.commentButton}>Post</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
});

function ProfileScreen() {
  const user = useGlobal(state => state.user);
  const updateProfile = useGlobal(state => state.updateProfile);
  const navigation = useNavigation();

  const [userPosts, setUserPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [nextPageUrl, setNextPageUrl] = useState(`https://${ADDRESS}/chat/posts/?user=${user.id}`);
  const [hasMore, setHasMore] = useState(true);
  const [userStats, setUserStats] = useState({ total_posts: 0, total_likes: 0 });
  const [editField, setEditField] = useState(null);
  const [currentValue, setCurrentValue] = useState('');

  const fetchUserStats = async () => {
    try {
      const tokens = await secure.get('tokens');
      if (!tokens?.access) return;
      const response = await axios.get(`https://${ADDRESS}/chat/users/${user.id}/stats/`, {
        headers: { Authorization: `Bearer ${tokens.access}` },
      });
      setUserStats(response.data);
    } catch (error) {
      console.error('Fetch stats error:', error);
    }
  };

  const fetchUserPosts = async (isRefreshing = false) => {
    if (loading || (!isRefreshing && !hasMore)) return;
    setLoading(true);
    setRefreshing(isRefreshing);

    try {
      const tokens = await secure.get('tokens');
      if (!tokens?.access) return;
      const url = isRefreshing ? `https://${ADDRESS}/chat/posts/?user=${user.id}` : nextPageUrl;

      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${tokens.access}` },
      });

      const results = response.data.results || [];
      const next = response.data.next;

      setUserPosts(prev => {
        const existingIds = new Set(prev.map(post => post.id));
        const newPosts = results.filter(post => !existingIds.has(post.id) && post.id);
        return isRefreshing ? newPosts : [...prev, ...newPosts];
      });
      setNextPageUrl(next);
      setHasMore(!!next);
    } catch (error) {
      console.error('Fetch error:', error);
      Alert.alert('Error', 'Failed to fetch posts');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchUserStats();
    fetchUserPosts();
  }, []);

  const handleLike = async postId => {
    try {
      const tokens = await secure.get('tokens');
      if (!tokens?.access) return;
      await axios.post(
        `https://${ADDRESS}/chat/posts/${postId}/like/`,
        {},
        { headers: { Authorization: `Bearer ${tokens.access}` } },
      );

      setUserPosts(prev =>
        prev.map(post =>
          post.id === postId
            ? {
                ...post,
                likes_count: post.is_liked ? (post.likes_count || 0) - 1 : (post.likes_count || 0) + 1,
                is_liked: !post.is_liked,
              }
            : post,
        ),
      );
    } catch (error) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to like');
    }
  };

  const handleRetweet = async postId => {
    try {
      const tokens = await secure.get('tokens');
      if (!tokens?.access) return;
      await axios.post(
        `https://${ADDRESS}/chat/posts/${postId}/retweet/`,
        {},
        { headers: { Authorization: `Bearer ${tokens.access}` } },
      );

      setUserPosts(prev =>
        prev.map(post =>
          post.id === postId
            ? {
                ...post,
                retweets_count: post.is_retweeted ? (post.retweets_count || 0) - 1 : (post.retweets_count || 0) + 1,
                is_retweeted: !post.is_retweeted,
              }
            : post,
        ),
      );
    } catch (error) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to retweet');
    }
  };

  const handleAddComment = async (postId, text) => {
    if (!text?.trim()) return;
    try {
      const tokens = await secure.get('tokens');
      if (!tokens?.access) return;
      const payload = { content: text };

      const response = await axios.post(
        `https://${ADDRESS}/chat/posts/${postId}/comments/`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${tokens.access}`,
            'Content-Type': 'application/json',
          },
        },
      );

      setUserPosts(prev =>
        prev.map(post =>
          post.id === postId
            ? {
                ...post,
                comments_count: (post.comments_count || 0) + 1,
                comments: [...(post.comments || []), response.data],
              }
            : post,
        ),
      );
    } catch (error) {
      Alert.alert(
        'Error',
        error.response?.data?.content?.[0] || 'Failed to post comment',
      );
    }
  };

  const handleEditStart = (field, value) => {
    setEditField(field);
    setCurrentValue(value);
  };

  const handleSave = async (value) => {
    await updateProfile({ [editField]: value });
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={userPosts}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <Post
            post={item}
            onLike={handleLike}
            onRetweet={handleRetweet}
            onAddComment={handleAddComment}
          />
        )}
        ListHeaderComponent={
          <View style={styles.headerContainer}>
            <ProfileImage />
            <Text style={styles.name}>{user.name || 'Enter your name'}</Text>
            <Text style={styles.username}>{user.username}</Text>
            <View style={styles.statsContainer}>
              <Text style={styles.statsText}>Posts: {userStats.total_posts}</Text>
              <Text style={styles.statsText}>Likes: {userStats.total_likes}</Text>
            </View>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Phone</Text>
              <Text style={styles.infoValue}>
                {user.phone?.replace(/(\d{2})(\d{5})(\d{5})/, '+$1 $2 $3')}
              </Text>
            </View>
            <TouchableOpacity
              style={styles.infoContainer}
              onPress={() => handleEditStart('bio', user.bio)}
            >
              <Text style={styles.infoLabel}>About</Text>
              <Text style={styles.infoValue}>{user.bio || 'Live a little'}</Text>
            </TouchableOpacity>
            <ProfileLogout />
          </View>
        }
        onEndReached={() => fetchUserPosts()}
        onEndReachedThreshold={0.5}
        refreshing={refreshing}
        onRefresh={() => fetchUserPosts(true)}
        ListFooterComponent={loading ? <ActivityIndicator size="large" color="#1DA1F2" /> : null}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>You haven't posted anything yet.</Text>
          </View>
        }
      />
      <EditModal
        visible={!!editField}
        initialValue={currentValue}
        onClose={() => setEditField(null)}
        onSave={handleSave}
        isBio={editField === 'bio'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  headerContainer: {
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 20,
  },
  name: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  username: {
    color: 'white',
    fontSize: 16,
    marginBottom: 10,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
    marginBottom: 20,
  },
  statsText: {
    color: 'white',
    fontSize: 16,
  },
  infoContainer: {
    width: '80%',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  infoLabel: {
    color: '#666',
    fontSize: 14,
    marginBottom: 4,
  },
  infoValue: {
    color: 'white',
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#2a2a2a',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
  },
  input: {
    backgroundColor: '#333',
    color: 'white',
    borderRadius: 10,
    padding: 15,
    fontSize: 18,
    marginBottom: 20,
    minHeight: 60,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  cancelButton: {
    backgroundColor: '#444',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  editIconContainer: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: 'green',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: 'white',
  },
  uploadOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 90,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutButton: {
    backgroundColor: '#FF3B30',
    padding: 15,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
    marginTop: 20,
  },
  logoutButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    color: 'white',
    fontSize: 16,
  },
  postContainer: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  postContent: {
    flex: 1,
  },
  postHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  userName: {
    color: 'white',
    fontWeight: 'bold',
    marginRight: 4,
  },
  timestamp: {
    color: '#666',
  },
  postText: {
    color: 'white',
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 12,
  },
  mediaContainer: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
  },
  mediaImage: {
    width: '100%',
    aspectRatio: 16 / 9,
    resizeMode: 'cover',
  },
  videoContainer: {
    position: 'relative',
    backgroundColor: 'black',
  },
  video: {
    width: '100%',
    aspectRatio: 16 / 9,
  },
  playButton: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -12 }, { translateY: -12 }],
  },
  postActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  actionCount: {
    color: '#666',
  },
  commentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    gap: 8,
  },
  commentInput: {
    flex: 1,
    color: 'white',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 20,
    padding: 8,
  },
  commentButton: {
    color: '#1DA1F2',
    fontWeight: 'bold',
  },
});

export default ProfileScreen;