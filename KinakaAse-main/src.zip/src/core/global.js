import { create } from 'zustand';
import secure from './secure';
import api, { ADDRESS } from './api';
import utils from './utils';
import axios from 'axios';
import NetInfo from '@react-native-community/netinfo';

async function getStoredMessages(connectionId) {
  const key = `messages_${connectionId}`;
  const stored = await secure.get(key);
  return stored ? JSON.parse(stored) : [];
}

async function saveStoredMessages(connectionId, messages) {
  const key = `messages_${connectionId}`;
  await secure.set(key, JSON.stringify(messages));
}

async function getStoredFriendList() {
  const stored = await secure.get('friendList');
  return stored ? JSON.parse(stored) : null;
}

async function saveStoredFriendList(friendList) {
  await secure.set('friendList', JSON.stringify(friendList));
}

function mergeMessages(existing, newMessages) {
  const existingIds = new Set(existing.map(m => m.id));
  const uniqueNew = newMessages.filter(m => !existingIds.has(m.id));
  return [...uniqueNew, ...existing].sort((a, b) => new Date(b.created) - new Date(a.created));
}

function getConnectionId(get, username) {
  const friendList = get().friendList;
  const friend = friendList?.find(f => f.friend.username === username);
  return friend ? friend.id : null;
}

function responseFriendList(set, get, friendList) {
  const unreadCounts = friendList.reduce((acc, friend) => {
    acc[friend.id] = friend.unread_count || 0;
    return acc;
  }, {});
  set(state => ({
    friendList: friendList,
    unreadCounts: { ...state.unreadCounts, ...unreadCounts },
  }));
  saveStoredFriendList(friendList);
  utils.log('responseFriendList:', friendList);
}

function responseFriendNew(set, get, friend) {
  const friendList = [friend, ...get().friendList];
  set({ friendList });
  saveStoredFriendList(friendList);
}

async function responseMessageList(set, get, data) {
  const username = data.friend.username;
  const connectionId = getConnectionId(get, username);
  if (!connectionId) return;

  const newMessages = data.messages;
  const storedMessages = await getStoredMessages(connectionId);
  const mergedMessages = mergeMessages(storedMessages, newMessages);
  await saveStoredMessages(connectionId, mergedMessages);

  set(state => ({
    messagesList: state.messagesUsername === username ? mergedMessages : state.messagesList,
    messagesNext: state.messagesUsername === username ? data.next : state.messagesNext,
    messagesUsername: state.messagesUsername === username ? username : state.messagesUsername,
  }));
  utils.log('responseMessageList:', mergedMessages);
}

async function responseMessageSend(set, get, data) {
  const username = data.friend.username;
  const connectionId = getConnectionId(get, username);
  if (!connectionId) return;

  const newMessage = data.message;
  const storedMessages = await getStoredMessages(connectionId);
  const updatedMessages = mergeMessages(storedMessages, [newMessage]);
  await saveStoredMessages(connectionId, updatedMessages);

  const user = get().user;
  const isSender = user.username === newMessage.user;

  const messageId = newMessage.id;
  const processedMessages = get().processedMessages || new Set();

  if (!processedMessages.has(messageId)) {
    set(state => {
      const friendList = state.friendList.map(item => {
        if (item.id === connectionId) {
          return {
            ...item,
            preview: newMessage.text,
            updated: newMessage.created,
            type: newMessage.type,
            replied_to: newMessage.replied_to,
          };
        }
        return item;
      });
      const updatedFriendList = friendList.filter(item => item.friend.username !== username);
      updatedFriendList.unshift(friendList.find(item => item.friend.username === username));

      return {
        friendList: updatedFriendList,
        messagesList: state.messagesUsername === username ? updatedMessages : state.messagesList,
        messagesTyping: state.messagesUsername === username ? null : state.messagesTyping,
        unreadCounts: {
          ...state.unreadCounts,
          [connectionId]: isSender ? state.unreadCounts[connectionId] : (state.unreadCounts[connectionId] || 0) + 1,
        },
        processedMessages: new Set([...processedMessages, messageId]),
      };
    });
    saveStoredFriendList(get().friendList);
    utils.log('responseMessageSend:', updatedMessages, 'unreadCounts:', get().unreadCounts);
  } else {
    utils.log('Duplicate message ignored:', messageId);
  }
}

function responseMessageType(set, get, data) {
  if (data.username !== get().messagesUsername) return;
  set({ messagesTyping: new Date() });
}

function responseRequestAccept(set, get, connection) {
  const user = get().user;
  if (user.username === connection.receiver.username) {
    const requestList = get().requestList.filter(req => req.id !== connection.id);
    set({ requestList });
  }
  const sl = get().searchList;
  if (sl) {
    const searchList = sl.map(userItem =>
      userItem.username === (user.username === connection.receiver.username ? connection.sender.username : connection.receiver.username)
        ? { ...userItem, status: 'connected' }
        : userItem
    );
    set({ searchList });
  }
}

function responseRequestConnect(set, get, connection) {
  const user = get().user;
  if (user.username === connection.sender.username) {
    const searchList = get().searchList?.map(req =>
      req.username === connection.receiver.username ? { ...req, status: 'pending-them' } : req
    );
    set({ searchList });
  } else {
    const requestList = get().requestList || [];
    if (!requestList.some(req => req.sender.username === connection.sender.username)) {
      set({ requestList: [connection, ...requestList] });
    }
  }
}

function responseRequestList(set, get, requestList) {
  set({ requestList });
}

function responseSearch(set, get, data) {
  set({ searchList: data });
}

function responseThumbnail(set, get, data) {
  set({ user: data });
}

function responseOnlineStatus(set, get, data) {
  utils.log('Received online status update:', data);
  const friendList = get().friendList.map(friend => {
    if (friend.friend.username === data.username) {
      return {
        ...friend,
        friend: {
          ...friend.friend,
          online: data.online,
        },
      };
    }
    return friend;
  });
  set({ friendList });
  saveStoredFriendList(friendList);
  utils.log('Updated friendList with online status:', friendList);
}

function responseGroupCreated(set, get, group) {
  const friendList = get().friendList || [];
  const newGroup = {
    id: `group_${group.id}`,
    friend: { username: group.name, name: group.name, thumbnail: null, online: true },
    preview: 'Group created',
    updated: group.created,
    type: 'text',
    unread_count: 0,
  };
  set(state => ({
    friendList: [newGroup, ...friendList],
    unreadCounts: { ...state.unreadCounts, [`group_${group.id}`]: 0 },
  }));
  saveStoredFriendList([newGroup, ...friendList]);
  utils.log('responseGroupCreated:', newGroup);
}

function responseMessageSeen(set, get, data) {
  set(state => ({
    unreadCounts: {
      ...state.unreadCounts,
      [data.connection_id]: Math.max(0, (state.unreadCounts[data.connection_id] || 0) - data.count),
    },
  }));
}

const useGlobal = create((set, get) => ({
  initialized: false,
  user: null,
  authenticated: false,
  socket: null,
  friendList: null,
  messagesList: [],
  messagesNext: null,
  messagesTyping: null,
  messagesUsername: null,
  requestList: [],
  searchList: null,
  unreadCounts: {},
  processedMessages: new Set(),
  messageQueue: [],
  notifications: [],

  init: async () => {
    const credentials = await secure.get('credentials');
    const storedUser = await secure.get('user');
    const storedTokens = await secure.get('tokens');
    const storedFriendList = await getStoredFriendList();

    if (credentials && storedUser && storedTokens) {
      const netInfo = await NetInfo.fetch();
      if (netInfo.isConnected) {
        await get().signIn();
      } else {
        set({
          authenticated: true,
          user: storedUser,
          friendList: storedFriendList || [],
        });
      }
    } else {
      set({ authenticated: false });
    }
    set({ initialized: true });

    NetInfo.addEventListener(state => {
      if (state.isConnected && !get().socket) {
        utils.log('Network connected, attempting WebSocket connection');
        get().socketConnect();
      } else if (!state.isConnected && get().socket) {
        utils.log('Network disconnected, closing WebSocket');
        get().socketClose();
      }
    });
  },

  signIn: async () => {
    const credentials = await secure.get('credentials');
    if (!credentials) {
      set({ authenticated: false });
      get().addNotification('No stored credentials found');
      return;
    }
    try {
      const response = await api({
        method: 'POST',
        url: '/chat/signin/',
        data: { username: credentials.username, password: credentials.password },
      });
      if (response.status !== 200) throw new Error('Authentication failed');
      const user = response.data.user;
      const tokens = response.data.tokens;
      await secure.set('tokens', tokens);
      await secure.set('user', user);
      set({ authenticated: true, user });
      get().socketConnect();
    } catch (error) {
      utils.log('Sign-in error:', error);
      set({ authenticated: false });
      get().addNotification('Sign-in failed: Invalid credentials');
    }
  },

  login: (credentials, user, tokens) => {
    secure.set('credentials', credentials);
    secure.set('tokens', tokens);
    secure.set('user', user);
    set({ authenticated: true, user });
    get().socketConnect();
  },

  logout: () => {
    secure.wipe();
    set({
      authenticated: false,
      user: null,
      socket: null,
      friendList: null,
      messagesList: [],
      messagesUsername: null,
      requestList: [],
      searchList: null,
      unreadCounts: {},
      processedMessages: new Set(),
      messageQueue: [],
      notifications: [],
    });
  },

  refreshToken: async () => {
    const tokens = await secure.get('tokens');
    const credentials = await secure.get('credentials');
    
    if (!tokens?.refresh && !credentials) {
      get().addNotification('No refresh token or credentials available');
      get().logout();
      return false;
    }

    // First try refreshing with refresh token
    if (tokens?.refresh) {
      try {
        const response = await api({
          method: 'POST',
          url: '/chat/token/refresh/',
          data: { refresh: tokens.refresh },
        });
        const newTokens = response.data;
        await secure.set('tokens', newTokens);
        get().socketConnect();
        return true;
      } catch (error) {
        utils.log('Refresh token failed:', error);
      }
    }

    // If refresh token fails or isn't available, use credentials
    if (credentials) {
      try {
        const response = await api({
          method: 'POST',
          url: '/chat/signin/',
          data: { username: credentials.username, password: credentials.password },
        });
        if (response.status !== 200) throw new Error('Authentication failed');
        const user = response.data.user;
        const newTokens = response.data.tokens;
        await secure.set('tokens', newTokens);
        await secure.set('user', user);
        set({ user });
        get().socketConnect();
        return true;
      } catch (error) {
        utils.log('Credentials refresh failed:', error);
        get().addNotification('Failed to refresh authentication');
        get().logout();
        return false;
      }
    }
    return false;
  },

  socketConnect: async () => {
    let tokens = await secure.get('tokens');
    if (!tokens?.access) {
      const refreshed = await get().refreshToken();
      if (!refreshed) {
        get().addNotification('Unable to establish WebSocket: Authentication failed');
        return;
      }
      tokens = await secure.get('tokens');
    }

    const connect = (attempt = 1, maxAttempts = 5) => {
      if (attempt > maxAttempts) {
        get().addNotification('Failed to reconnect after multiple attempts');
        return;
      }
      const url = `wss://${ADDRESS}/chat/?token=${tokens.access}`;
      const socket = new WebSocket(url);

      socket.onopen = () => {
        utils.log('socket.onopen');
        socket.send(JSON.stringify({ source: 'request.list' }));
        socket.send(JSON.stringify({ source: 'friend.list' }));
        socket.send(JSON.stringify({ source: 'online.status' }));
        const interval = setInterval(() => {
          if (socket.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({ source: 'online.status' }));
          } else {
            clearInterval(interval);
          }
        }, 5000);
        const currentUsername = get().messagesUsername;
        if (currentUsername) {
          const connectionId = getConnectionId(get, currentUsername);
          if (connectionId) socket.send(JSON.stringify({ source: 'message.list', connectionId, page: 0 }));
        }
        get().flushQueue();
      };

      socket.onmessage = async event => {
        const parsed = JSON.parse(event.data);
        utils.log('onmessage:', parsed);
        if (parsed.source === 'error') {
          if (parsed.data.message === 'Invalid token') {
            const refreshed = await get().refreshToken();
            if (refreshed) {
              get().socketClose();
              get().socketConnect();
            }
          }
          get().addNotification('WebSocket error: ' + parsed.data.message);
          return;
        }
        const responses = {
          'friend.list': responseFriendList,
          'friend.new': responseFriendNew,
          'message.list': responseMessageList,
          'message.send': responseMessageSend,
          'message.type': responseMessageType,
          'request.accept': responseRequestAccept,
          'request.connect': responseRequestConnect,
          'request.list': responseRequestList,
          'search': responseSearch,
          'thumbnail': responseThumbnail,
          'group.created': responseGroupCreated,
          'online.status': responseOnlineStatus,
          'message.seen': responseMessageSeen,
        };
        const resp = responses[parsed.source];
        if (!resp) {
          utils.log('Unknown source:', parsed.source);
          return;
        }
        resp(set, get, parsed.data);
      };

      socket.onerror = e => utils.log('socket.onerror', e.message);

      socket.onclose = () => {
        utils.log('socket.onclose');
        set({ socket: null });
        const delay = Math.min(1000 * Math.pow(2, attempt - 1), 10000);
        utils.log(`Reconnecting in ${delay}ms (attempt ${attempt})`);
        setTimeout(() => connect(attempt + 1, maxAttempts), delay);
      };

      set({ socket });
    };

    connect();
  },

  socketClose: () => {
    const socket = get().socket;
    if (socket) socket.close();
    set({ socket: null });
  },

  searchUsers: query => {
    if (!query) {
      set({ searchList: null });
      return;
    }
    const socket = get().socket;
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ source: 'search', query }));
    } else {
      get().addNotification('Cannot search users: No WebSocket connection');
    }
  },

  messageList: async (connectionId, page = 0) => {
    const storedMessages = await getStoredMessages(connectionId);
    const friend = get().friendList?.find(f => f.id === connectionId);
    if (!friend) {
      get().addNotification('Conversation not found');
      return;
    }
    const username = friend.friend.username;

    set({
      messagesList: page === 0 ? storedMessages : get().messagesList,
      messagesNext: null,
      messagesUsername: username,
      messagesTyping: null,
    });
    utils.log('messageList loaded:', storedMessages);

    const socket = get().socket;
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ source: 'message.list', connectionId, page }));
    } else {
      get().addNotification('Messages loaded from storage only: No WebSocket connection');
    }
  },

  messageSend: (connectionId, message, type, replied_to, isGroup, incognito, disappearing, file) => {
    const socket = get().socket;
    const payload = {
      source: 'message.send',
      connectionId,
      message,
      type,
      replied_to,
      isGroup,
      incognito,
      disappearing,
    };
    if (file) payload.file = file;

    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(payload));
    } else {
      set(state => ({ messageQueue: [...state.messageQueue, payload] }));
      get().addNotification('Message queued due to no connection');
    }
  },

  flushQueue: () => {
    const socket = get().socket;
    if (socket && socket.readyState === WebSocket.OPEN) {
      const queue = get().messageQueue;
      queue.forEach(payload => socket.send(JSON.stringify(payload)));
      set({ messageQueue: [] });
      get().addNotification('Queued messages sent', 'success');
    }
  },

  messageType: username => {
    clearTimeout(get().typingTimeout);
    set({ typingTimeout: setTimeout(() => {
      const socket = get().socket;
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ source: 'message.type', username }));
      }
    }, 500) });
  },

  requestAccept: username => {
    const socket = get().socket;
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ source: 'request.accept', username }));
    } else {
      get().addNotification('Cannot accept request: No WebSocket connection');
    }
  },

  requestConnect: username => {
    const socket = get().socket;
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ source: 'request.connect', username }));
    } else {
      get().addNotification('Cannot send request: No WebSocket connection');
    }
  },

  createGroup: name => {
    const socket = get().socket;
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ source: 'groups.create', name }));
    } else {
      get().addNotification('Cannot create group: No WebSocket connection');
    }
  },

  uploadFile: async (file, endpoint) => {
    const netInfo = await NetInfo.fetch();
    if (!netInfo.isConnected) {
      get().addNotification('File upload queued due to no connection');
      return null;
    }
    const formData = new FormData();
    formData.append('file', { uri: file.uri, name: file.fileName, type: file.type });
    let tokens = await secure.get('tokens');
    if (!tokens?.access) {
      const refreshed = await get().refreshToken();
      if (!refreshed) return null;
      tokens = await secure.get('tokens');
    }
    try {
      const response = await axios.post(
        `https://${ADDRESS}/chat/${endpoint}/`,
        formData,
        { headers: { 'Content-Type': 'multipart/form-data', Authorization: `Bearer ${tokens.access}` } }
      );
      return response.data.fileUrl || response.data[endpoint];
    } catch (error) {
      get().addNotification(`Failed to upload ${endpoint}: ${error.message}`);
      throw error;
    }
  },

  uploadThumbnail: async file => {
    const fileUrl = await get().uploadFile(file, 'upload');
    if (fileUrl) {
      const socket = get().socket;
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ source: 'thumbnail', fileUrl }));
      }
    }
  },

  sendImage: async file => {
    const fileUrl = await get().uploadFile(file, 'upload');
    if (fileUrl) {
      const socket = get().socket;
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ source: 'image', fileUrl }));
      }
    }
  },

  uploadBgImage: async file => {
    const netInfo = await NetInfo.fetch();
    if (!netInfo.isConnected) {
      get().addNotification('Background image upload queued due to no connection');
      return;
    }
    const formData = new FormData();
    formData.append('user_Bg_thumbnail', { uri: file.uri, name: file.fileName, type: file.type });
    let token = await secure.get('tokens');
    if (!token?.access) {
      const refreshed = await get().refreshToken();
      if (!refreshed) return;
      token = await secure.get('tokens');
    }
    try {
      const response = await axios.post(
        `https://${ADDRESS}/chat/upload-bg-thumbnail/`,
        formData,
        { headers: { 'Content-Type': 'multipart/form-data', Authorization: `Bearer ${token.access}` } }
      );
      utils.log('Upload successful:', response.data);
      get().addNotification('Background image uploaded successfully', 'success');
    } catch (error) {
      utils.log('Upload failed:', error);
      get().addNotification('Failed to upload background image');
    }
  },

  addNotification: (message, type = 'error') => {
    set(state => ({ notifications: [...state.notifications, { message, type, id: Date.now() }] }));
  },

  clearNotification: id => {
    set(state => ({ notifications: state.notifications.filter(n => n.id !== id) }));
  },

  typingTimeout: null,
}));

export default useGlobal;